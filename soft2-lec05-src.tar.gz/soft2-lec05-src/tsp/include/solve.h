#pragma once
#include "city.h"

double solve(const City *city, int n, int *route, int *visited);

