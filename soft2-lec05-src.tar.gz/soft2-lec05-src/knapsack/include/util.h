#pragma once

// エラー判定付きの読み込み関数
int load_int(const char *argvalue);
double load_double(const char *argvalue);
